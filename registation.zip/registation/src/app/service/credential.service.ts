import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CredentialService {

  constructor(private http: HttpClient) { }

  getCredentialFromLocalJson(): Observable<any> {
    return this.http.get<any>('assets/json/credential.json');
  }
}

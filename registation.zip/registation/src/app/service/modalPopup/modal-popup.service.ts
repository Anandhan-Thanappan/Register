import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class ModalPopupService {

  constructor(private router:Router, private route: ActivatedRoute) { }



  // Success pop up
  successAlert(text, linkToRedirect){
    Swal.fire({
      title: 'Successful!',
      text: text,
      icon: 'success',
      showCancelButton: false,
      showCloseButton: false,
      allowOutsideClick: false,
      showConfirmButton:true,
      // timer: 5000
    }).then((result) => {
      if (result.value) {
        this.router.navigate([linkToRedirect], { relativeTo: this.route });
      }
    })
  }


    // Failure pop up
    failureAlert(text){
      Swal.fire({
        title: 'Failed!',
        text: text,
        icon: 'error',
        showCancelButton: false,
        showCloseButton: false,
        allowOutsideClick: false,
        showConfirmButton:false,
        timer: 3000
      }).then((result) => {
        if (result.value) {
        }
      })
    }

    // Info

    swalErrorInfo() {
      Swal.fire({
        title: "Failed!",
        text: "User not Registered",
        icon: 'info',
        showCancelButton: false,
        confirmButtonText: 'Ok',
        showCloseButton: false,
        // confirmButtonClass: 'btn btn-danger',
        customClass: {
          confirmButton: 'btn btn-danger',
          container: 'error_info'
        },
        showConfirmButton:false,
        timer: 3000
      }).then((result) => {
        if (result.value) {
        }
      })
    }



}

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ModalPopupService } from '../modalPopup/modal-popup.service';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private http: HttpClient, private modalPopupService: ModalPopupService) {
    this.getRegisteredUser();
  }


  registeredUser = [];
  selectedUser = {};
  allEntries;

  // Set Created registration user
  setRegisteredUser(user) {
    // this.registeredUser.push(user);

    this.allEntries = JSON.parse(localStorage.getItem("registeredUser")) || [];

    if (this.allEntries.length) {
      let ifUserRegistered = this.allEntries.find(data => {
        return data.emaild == user.emaild;
      });

      if (typeof ifUserRegistered === 'undefined') {

        this.createUser(user);
      } else {
        // Alert message 
        this.modalPopupService.failureAlert("User already Registered");
      }
    } else {
      this.createUser(user);
    }

  }

  // Register user
  createUser(user) {
    this.allEntries.push(user);
    localStorage.setItem("registeredUser", JSON.stringify(this.allEntries));
    // Alert message 
    this.modalPopupService.successAlert("User created Successfully", "../login");
  }


  // get registration user
  getRegisteredUser() {
    this.registeredUser = JSON.parse(localStorage.getItem("registeredUser")) || [];
    return this.registeredUser;
  }


  // Set user
  setUserObject(user) {
    this.selectedUser = user;
  }

  // get user
  getUserObject() {
    return this.selectedUser;
  }



  // Load data from local JSON
  /* getCredentialFromLocalJson(): Observable<any> {
    return this.http.get<any>('assets/json/credential.json');
  } */

}

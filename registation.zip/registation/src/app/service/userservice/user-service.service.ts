import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private http: HttpClient) { }


  registeredUser = [];
  selectedUser = {};


  // Set Created registration user
  setRegisteredUser(user) {
    this.registeredUser.push(user);
  }

  // get registration user
  getRegisteredUser() {
    return this.registeredUser;
  }


  // Set user
  setUserObject(user) {
    this.selectedUser = user;
  }

  // get user
  getUserObject() {
    return this.selectedUser;
  }



  // Load data from local JSON
  /* getCredentialFromLocalJson(): Observable<any> {
    return this.http.get<any>('assets/json/credential.json');
  } */

}

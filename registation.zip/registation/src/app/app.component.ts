import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReCaptcha2Component } from 'ngx-captcha';
import { CredentialType } from './model/credetialType';
import { CredentialService } from './service/credential.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'registation';
  credentials: CredentialType[];
  registerForm: FormGroup;
  captchaStatus: boolean;

  @ViewChild('captchaElem') captchaElem: ReCaptcha2Component;
  public theme: 'light' | 'dark' = 'light';
  public size: 'compact' | 'normal' = 'normal';
  public lang = 'en';
  public type: 'image' | 'audio';
  captchaBlock: boolean = false;

  constructor(private credetial: CredentialService,
    private formBuilder: FormBuilder) {

  }


  ngOnInit() {
    // Get all the credetila from local JSON form JSON file
    this.credetial.getCredentialFromLocalJson().subscribe(dataSource => {
      this.credentials = dataSource;
    });
    this.registerFormValidation();
  }


  // Initialize the form fields
  registerFormValidation() {
    this.registerForm = this.formBuilder.group({
      id: [null],
      emaild: ['', []],
      password: [''],
      recaptcha: ['', Validators.required]
    });
  }



  // Click to Register
  createRegister() {
    let enteredPassword = this.registerForm.value.password;

    let filteredUser = this.credentials.find(data => {
      if (data.emaild == this.registerForm.value.emaild) {
        return data;
      };
    });

    if (enteredPassword == filteredUser.password) {
      // Call API method
      alert("Success");

    } else {
      this.captchaStatus = true;
      setTimeout(() => {
        this.captchaStatus = false; 
        this.captchaBlock = true;
      }, 3000)
    }

    if(this.registerForm.value.recaptcha){
      this.captchaStatus = false;
      alert('Success');
    }


  }



  handleSuccess(e) {
    console.log("ReCaptcha", e);
  }

}

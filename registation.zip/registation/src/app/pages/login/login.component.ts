import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserServiceService } from 'src/app/service/userservice/user-service.service';
import { ModalPopupService } from 'src/app/service/modalPopup/modal-popup.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup
  Email: any;
  captchaStatus: boolean = false;
  constructor(private formBuilder: FormBuilder,
    private router: Router, private route: ActivatedRoute, private userServiceService: UserServiceService,
    private modalPopupService: ModalPopupService) { }

  ngOnInit(): void {
    this.registerLoginControls();
  }


  // Initialize the form fields
  registerLoginControls() {
    this.loginForm = this.formBuilder.group({
      id: [null],
      emaild: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.pattern('.{6,}')]]
    });
  }

  // User login
  userLogin() {

    // To check if user already registered
    if (this.userServiceService.registeredUser.length) {
      let ifUserRegistered = this.userServiceService.registeredUser.find(data => {
        return ((data.emaild == this.loginForm.value.emaild) && data.password == (this.loginForm.value.password));
      });

      if (typeof ifUserRegistered === 'undefined') {
        this.captchaStatus = true;
        setTimeout(() => {
          this.captchaStatus = false;
        }, 3000);

      } else {
        this.router.navigate(['../welcome'], { relativeTo: this.route });
      }
    } else {
      // Alert message 
      this.modalPopupService.failureAlert("User not Registered in this Email-ID");
    }
  }

  // forgotPassword()
  forgotPassword() {

    // To check if user already registered
    if (this.userServiceService.registeredUser.length) {
      let ifUserRegistered = this.userServiceService.registeredUser.find(data => {
        if (data.emaild == this.loginForm.value.emaild) {
          this.userServiceService.setUserObject(data);
          return true;
        }
      });

      if (typeof ifUserRegistered === 'undefined') {
        // Alert message 
        this.modalPopupService.failureAlert("User not Registered in this Email-ID");
      } else {
        this.router.navigate(['../captcha'], { relativeTo: this.route });
      }
    } else {
      // Alert message 
      this.modalPopupService.failureAlert("User not Registered in this Email-ID");
    }
  }

  // backButton
  backButton() {
    // Alert message 
    this.router.navigate(['../register'], { relativeTo: this.route });
  }

}

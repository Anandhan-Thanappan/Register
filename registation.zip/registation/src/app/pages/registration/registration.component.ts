import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalPopupService } from 'src/app/service/modalPopup/modal-popup.service';
import { UserServiceService } from 'src/app/service/userservice/user-service.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {


  registerForm: FormGroup

  constructor(private formBuilder: FormBuilder, private modalPopupService: ModalPopupService,
    private userServiceService: UserServiceService, private router:Router, private route: ActivatedRoute) {

  }

  ngOnInit() {
    //Load form 
    this.registerFormControls();
  }

  // Initialize the form fields
  registerFormControls() {
    this.registerForm = this.formBuilder.group({
      id: [null],
      name: ['', Validators.required],
      emaild: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.pattern('.{6,}')]]
    });
  }

  // Click to Register
  createRegister() {

    // To check if user already registered
    if (this.userServiceService.registeredUser.length) {
      let ifUserRegistered = this.userServiceService.registeredUser.find(data => {
        return data.emaild == this.registerForm.value.emaild;
      });

      if (typeof ifUserRegistered === 'undefined') {
        this.createUser();
      } else {
        // Alert message 
        this.modalPopupService.failureAlert("User already Registered");
      }
    } else {
      this.createUser();
    }

  }


  // Register user
  createUser() {
    // Add registered user
    this.userServiceService.setRegisteredUser(this.registerForm.value);

    // Alert message 
    this.modalPopupService.successAlert("User created Successfully", "../login");
  }


  // alreadyRegister
  alreadyRegister(){
    this.router.navigate(['../login'], { relativeTo: this.route });
  }

}

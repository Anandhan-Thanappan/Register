import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ReCaptcha2Component } from 'ngx-captcha';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalPopupService } from 'src/app/service/modalPopup/modal-popup.service';
import { UserServiceService } from 'src/app/service/userservice/user-service.service';
declare var Email: any;

@Component({
  selector: 'app-captcha',
  templateUrl: './captcha.component.html',
  styleUrls: ['./captcha.component.css']
})
export class CaptchaComponent implements OnInit {
  captchaForm: FormGroup;
  @ViewChild('captchaElem') captchaElem: ReCaptcha2Component;
  public theme: 'light' | 'dark' = 'light';
  public size: 'compact' | 'normal' = 'normal';
  public lang = 'en';
  public type: 'image' | 'audio';
  captchaBlock: boolean = false;
  selectedUser: {};

  constructor(private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute,
    private modalPopupService: ModalPopupService, private userServiceService: UserServiceService) { }

  ngOnInit(): void {
    this.registerCaptchaControls();
    this.captchaForm.get('emaild').disable();

    // Getting selected User
    this.selectedUser = this.userServiceService.selectedUser;

    this.captchaForm.patchValue({
      emaild: this.selectedUser['emaild']
    });
  }


  // Initialize the form fields
  registerCaptchaControls() {
    this.captchaForm = this.formBuilder.group({
      id: [null],
      emaild: ['', [Validators.required, Validators.email]],
      recaptcha: ['', [Validators.required, Validators.pattern('.{6,}')]]
    });
  }


  // userLogin
  userLogin() {
    let finalUrl = "http://" + document.location.host + "/resetPassword";

    let localStorageObject = this.selectedUser;

    // Put the object into storage
    localStorage.setItem('userObject', JSON.stringify(localStorageObject));

    new Email.send({
      Host: "smtp.gmail.com",
      Username: "reachmeanandhan@gmail.com",
      Password: "123456789aA@",
      To: this.selectedUser['emaild'],
      From: "reachmeanandhan@gmail.com",
      Subject: "Reset Password",
      Body: '<div style="background: #c6eeea; padding: 10px;">' +
        '<p style="color:#A6A6A6">Hello ' + this.selectedUser['name'] + ',</p>' +
        '<p style="color:#A6A6A6">' +
        'We have received a request to reset your password to Us. If you made this request,' +
        'Click <a style="color:#009688" href="' + finalUrl + '">here</a> to change your password.' + 'If you did not request a new password please ignore this message.</p> ' +
        '<p style="color:#A6A6A6">Regards,<br>Password Team</p>' +
        '</div>'
    })
      .then(function (message) {
        alert("Mail has sent to given Email-Id to Reset Password");
      });

  }

  redirect() {
    // Alert message 
    this.modalPopupService.successAlert("Mail has sent to given Email-Id", "../login");
  }


  // forgotPassword
  forgotPassword() {

  }

  handleSuccess(event) {

  }


  // backButton
  backButton() {
    // Alert message 
    this.router.navigate(['../login'], { relativeTo: this.route });
  }

}

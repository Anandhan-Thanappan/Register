import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { UserServiceService } from 'src/app/service/userservice/user-service.service';
import { ModalPopupService } from 'src/app/service/modalPopup/modal-popup.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  resetPasswordForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private userServiceService: UserServiceService,
    private modalPopupService: ModalPopupService) { }

  retrievedUserObject;
  ngOnInit(): void {
    this.registerResetPasswordControls();
    // Disable the Email-Id & Password field
    this.resetPasswordForm.controls['emaild'].disable();
    this.resetPasswordForm.controls['password'].disable();

    // Retrieve the object from storage
    var retrievedObject = localStorage.getItem('userObject');
    this.retrievedUserObject = JSON.parse(retrievedObject);

    // Fill the detail in the form
    this.resetPasswordForm.patchValue({
      emaild: this.retrievedUserObject['emaild'],
      password: this.retrievedUserObject['password']
    });

  }


  // Initialize the form fields
  registerResetPasswordControls() {
    this.resetPasswordForm = this.formBuilder.group({
      id: [null],
      emaild: [''],
      password: [''],
      confirmPassword: ['', [Validators.required, Validators.pattern('.{6,}')]]
    });
  }


  // resetPassword
  resetPassword() {
    // To check if user already registered
    let allEntries = this.userServiceService.getRegisteredUser();
    allEntries.map((data) => {
      if (data.emaild == this.retrievedUserObject['emaild']) {
        data.password = this.resetPasswordForm.value.confirmPassword
      }
    });

    localStorage.setItem("registeredUser", JSON.stringify(allEntries));

    this.modalPopupService.successAlert("Password reseted Successfully", "../login");

  }

}

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { UserServiceService } from 'src/app/service/userservice/user-service.service';
import { ModalPopupService } from 'src/app/service/modalPopup/modal-popup.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  resetPasswordForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private userServiceService: UserServiceService,
    private modalPopupService:ModalPopupService) { }

  ngOnInit(): void {
    this.registerResetPasswordControls();
    // Disable the Email-Id & Password field
    this.resetPasswordForm.controls['emaild'].disable();
    this.resetPasswordForm.controls['password'].disable();

    // Retrieve the object from storage
    var retrievedObject = localStorage.getItem('userObject');
    let retrievedUserObject = JSON.parse(retrievedObject);

    this.resetPasswordForm.patchValue({
      emaild: retrievedUserObject['emaild'],
      password: retrievedUserObject['password']
    });

  }


  // Initialize the form fields
  registerResetPasswordControls() {
    this.resetPasswordForm = this.formBuilder.group({
      id: [null],
      emaild: [''],
      password: [''],
      confirmPassword: ['', [Validators.required, Validators.pattern('.{6,}')]]
    });
  }


  // resetPassword
  resetPassword() {
   let user = this.userServiceService.getRegisteredUser();
   this.modalPopupService.successAlert("Password reseted Successfully", "../login");

  }

}

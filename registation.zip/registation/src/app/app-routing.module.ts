import { WelcomeComponent } from './pages/welcome/welcome.component';
import { LoginComponent } from './pages/login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationComponent } from './pages/registration/registration.component';
import { CaptchaComponent } from './pages/captcha/captcha.component';
import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';


const routes: Routes = [
  {
    path: 'register',
    component: RegistrationComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'resetPassword',
    component: ForgotPasswordComponent
  },
  {
    path: 'welcome',
    component: WelcomeComponent
  },
  {
    path: 'captcha',
    component: CaptchaComponent
  },
  {
    path: '',
    redirectTo: '/register',
    pathMatch: 'full'
  },
  {
    path: '**',
    component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const exportComponent = [
  LoginComponent,
  RegistrationComponent,
  CaptchaComponent,
  PageNotFoundComponent,
  ForgotPasswordComponent,
  WelcomeComponent
]

export interface CredentialType {
    id:number,
    emaild:string,
    password:string
}
